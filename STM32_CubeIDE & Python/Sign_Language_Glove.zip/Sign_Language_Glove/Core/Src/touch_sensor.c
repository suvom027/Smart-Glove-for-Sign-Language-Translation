/*
 * touch_sensor.c
 *
 *  Created on: Jan 24, 2025
 *      Author: Acer
 */
#include "touch_sensor.h"

// Function to read and average touch sensor data
void Read_Touch_Sensors(uint16_t *averagedTouch) {
    uint8_t touchSensors[16][2]; // Temporary storage for 16 readings

    for (int i = 0; i < 16; i++) {
        touchSensors[i][0] = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0); // Touch Sensor 1
        touchSensors[i][1] = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1); // Touch Sensor 2
        HAL_Delay(1); // Small delay between readings
    }

    averagedTouch[0] = 0;
    averagedTouch[1] = 0;
    for (int i = 0; i < 16; i++) {
        averagedTouch[0] += touchSensors[i][0];
        averagedTouch[1] += touchSensors[i][1];
    }
    averagedTouch[0] /= 16; // Average for Touch Sensor 1
    averagedTouch[1] /= 16; // Average for Touch Sensor 2
}


