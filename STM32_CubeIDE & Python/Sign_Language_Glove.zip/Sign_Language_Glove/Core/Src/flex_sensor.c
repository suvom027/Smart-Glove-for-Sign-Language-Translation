/*
 * flex_sensor.c
 *
 *  Created on: Jan 24, 2025
 *      Author: Acer
 */
#include "flex_sensor.h"
#include "adc.h"
#include "i2c.h"
#include "iwdg.h"
#include "usart.h"
#include "gpio.h"

// Function to read and average flex sensor data
void Read_Flex_Sensors(uint16_t *flexAveraged) {
    uint16_t flexReadings[5][16] = {0}; // Temporary storage for 16 readings per sensor

    // Perform 16 ADC conversions for each flex sensor
    for (int i = 0; i < 16; i++) {
        for (int j = 0; j < 5; j++) {
            ADC_ChannelConfTypeDef sConfig = {0};

            // Configure the ADC channel dynamically based on the sensor index
            sConfig.Channel = ADC_CHANNEL_0 + j; // PA0=Channel 0, PA1=Channel 1, etc.
            sConfig.Rank = ADC_REGULAR_RANK_1;
            sConfig.SamplingTime = ADC_SAMPLETIME_55CYCLES_5;

            if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) {
                Error_Handler(); // Handle ADC configuration error
            }

            HAL_ADC_Start(&hadc1);
            HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY);
            flexReadings[j][i] = HAL_ADC_GetValue(&hadc1);
            HAL_ADC_Stop(&hadc1);
        }
    }

    // Compute the average value for each flex sensor
    for (int j = 0; j < 5; j++) {
        flexAveraged[j] = 0;
        for (int i = 0; i < 16; i++) {
            flexAveraged[j] += flexReadings[j][i];
        }
        flexAveraged[j] /= 16;
    }
}


