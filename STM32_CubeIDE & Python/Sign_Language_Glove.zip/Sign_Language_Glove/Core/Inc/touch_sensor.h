/*
 * touch_sensor.h
 *
 *  Created on: Jan 24, 2025
 *      Author: Acer
 */

#ifndef INC_TOUCH_SENSOR_H_
#define INC_TOUCH_SENSOR_H_

#include "stm32f1xx_hal.h"
#include "main.h"

// Function to read and average touch sensor data
void Read_Touch_Sensors(uint16_t *averagedTouch);

#endif /* INC_TOUCH_SENSOR_H_ */
