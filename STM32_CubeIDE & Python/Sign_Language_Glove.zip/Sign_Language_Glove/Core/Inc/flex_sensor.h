/*
 * flex_sensor.h
 *
 *  Created on: Jan 24, 2025
 *      Author: Acer
 */

#ifndef INC_FLEX_SENSOR_H_
#define INC_FLEX_SENSOR_H_

#include "stm32f1xx_hal.h"
#include "main.h"
#include "adc.h"
#include "i2c.h"
#include "iwdg.h"
#include "usart.h"
#include "gpio.h"

// Function to read and average flex sensor data
void Read_Flex_Sensors(uint16_t *flexAveraged);

#endif /* INC_FLEX_SENSOR_H_ */
